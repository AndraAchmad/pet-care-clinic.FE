@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h1>Layanan Kami</h1>
    <ul class="list-group">
        <li class="list-group-item">Pemeriksaan Kesehatan Umum</li>
        <li class="list-group-item">Vaksinasi</li>
        <li class="list-group-item">Sterilisasi</li>
        <li class="list-group-item">Perawatan Gigi</li>
        <li class="list-group-item">Penitipan Hewan</li>
    </ul>
</div>
@endsection
