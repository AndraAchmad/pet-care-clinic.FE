@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h1>Hubungi Kami</h1>
    <p>Telepon: 0812-3456-7890</p>
    <p>Email: info@petcareclinic.com</p>
    <p>Alamat: Jl. Contoh No.123, Purwokerto</p>
</div>
@endsection
