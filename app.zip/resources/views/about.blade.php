@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h1>Tentang Kami</h1>
    <p>Kami adalah tim profesional yang peduli pada kesehatan dan kesejahteraan hewan peliharaan Anda.</p>
    <p>Dengan pengalaman bertahun-tahun, Pet Care Clinic siap memberikan layanan terbaik untuk Anda dan hewan kesayangan Anda.</p>
</div>
@endsection
