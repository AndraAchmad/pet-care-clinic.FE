

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Layanan Kami</h1>
    <ul class="list-group">
        <li class="list-group-item">Pemeriksaan Kesehatan Umum</li>
        <li class="list-group-item">Vaksinasi</li>
        <li class="list-group-item">Sterilisasi</li>
        <li class="list-group-item">Perawatan Gigi</li>
        <li class="list-group-item">Penitipan Hewan</li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pet-care-clinic\resources\views/services.blade.php ENDPATH**/ ?>