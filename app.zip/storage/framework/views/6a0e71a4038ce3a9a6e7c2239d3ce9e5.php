<nav class="navbar navbar-expand-lg" style="background-color: #D3EE98; padding: 1rem 2rem;">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo e(route('home')); ?>" style="font-family: 'Sora', sans-serif; font-size: 1.8rem; color: #29421D;">
            Pet Care Clinic
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('about')); ?>">About</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('services')); ?>">Services</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a></li>

                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="btn btn-outline-dark me-2" href="<?php echo e(route('login')); ?>">Login</a>
                </li>
                <li class="nav-item">
                    <a class="btn btn-success" href="<?php echo e(route('register')); ?>">Download App</a>
                </li>
                <?php else: ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        Hi, <?php echo e(Auth::user()->name); ?>

                    </a>
                    <ul class="dropdown-menu">
                        <?php if(Auth::user()->role === 'admin'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <?php endif; ?>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item">Logout</button>
                            </form>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\pet-care-clinic\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>