

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Hubungi Kami</h1>
    <p>Telepon: 0812-3456-7890</p>
    <p>Email: info@petcareclinic.com</p>
    <p>Alamat: Jl. Contoh No.123, Purwokerto</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pet-care-clinic\resources\views/contact.blade.php ENDPATH**/ ?>