

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Tentang Kami</h1>
    <p>Kami adalah tim profesional yang peduli pada kesehatan dan kesejahteraan hewan peliharaan Anda.</p>
    <p>Dengan pengalaman bertahun-tahun, Pet Care Clinic siap memberikan layanan terbaik untuk Anda dan hewan kesayangan Anda.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pet-care-clinic\resources\views/about.blade.php ENDPATH**/ ?>